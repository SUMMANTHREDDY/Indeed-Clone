const config = {
    secret: 'cmpe273_Indeed',
    mongoDB: 'mongodb+srv://root:indeed123@indeedcluster.cvgcp.mongodb.net/Indeed?retryWrites=true&w=majority',
    REACT_APP_ACCESS_ID:`AKIA4R54L2KAYHNNAG7M`,
    REACT_APP_ACCESS_KEY:`RZrKv2sYggUEgt8oDVsM1bOMp97QHsya0s78rm7N`,
    REACT_APP_BUCKET_NAME:`indeed13`,
    REACT_APP_REGION:`us-east-2`,

}

module.exports = config;
