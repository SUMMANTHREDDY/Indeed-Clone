# Indeed-Clone

Clone of Web application Indeed using MERN stack.
