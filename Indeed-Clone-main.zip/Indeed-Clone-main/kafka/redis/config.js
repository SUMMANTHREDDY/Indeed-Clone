module.exports = {
  redisPort: 6379,
  redisHost: '18.119.28.164',
  redisPass: 'secure-redis',
};
