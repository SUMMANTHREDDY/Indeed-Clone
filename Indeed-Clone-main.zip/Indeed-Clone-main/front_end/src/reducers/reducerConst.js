export const ACTION = {
  SHOWERROR: "error",
  SHOWMESSAGE: "message"
};

export const STATE = {
  ERR_MSG: "errorMessage",
  IS_ERROR: false,
};
