const config = {
  SERVERURL: 'http://54.177.141.105:8080',
};

export const STORAGE = {
  isSignedIn: 'isSignedIn',
  accountType: 'accountType',
  emailId: 'emailId',
  token: 'token',
  companyId: 'companyId',
  details: 'details',
  userId: 'userId',
};

export default config;
