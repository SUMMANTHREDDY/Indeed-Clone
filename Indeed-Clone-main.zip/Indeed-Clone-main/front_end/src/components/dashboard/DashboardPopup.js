import React from 'react'

export const DashboardPopup = () => {
    return (
        <div>
            <p>This is popup</p>
        </div>
    )
}
